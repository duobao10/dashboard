import paho.mqtt.client as mqtt
import json
import sqlite3

mqtt_broker = "149.165.159.142"
mqtt_port = 1883

mqtt_topic_prefix = "test/topic/"

db_path = "dashboard.db"

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# 创建表格

conn.commit()

def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    client.subscribe(mqtt_topic_prefix + 'sensor_data/temperature')
    client.subscribe(mqtt_topic_prefix + 'evom_data/teer')

def on_message(client, userdata, msg):
    print(f"Received message on topic {msg.topic}: {msg.payload}")

    try:
        data = json.loads(msg.payload)
        if msg.topic == mqtt_topic_prefix + 'sensor_data/temperature':
            # 处理温度数据并插入到SQLite数据库的表中
            handle_temperature_data(data)
        elif msg.topic == mqtt_topic_prefix + 'evom_data/teer':
            # 处理TEER数据并插入到SQLite数据库的表中
            handle_teer_data(data)

    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")

def handle_temperature_data(data):
    sql = "INSERT INTO sensor_temperature (sensor1, sensor2, sensor3, sensor4) VALUES (?, ?, ?, ?)"
    values = (data['sensor1'], data['sensor2'], data['sensor3'], data['sensor4'])
    cursor.execute(sql, values)
    conn.commit()

def handle_teer_data(data):
    sql = "INSERT INTO evom_teer (barrier_resistance) VALUES (?)"
    values = (data['barrierResistance'],)
    cursor.execute(sql, values)
    conn.commit()

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.on_connect = on_connect
client.on_message = on_message

client.connect(mqtt_broker, mqtt_port, 60)

client.loop_forever(retry_first_connection=False)

