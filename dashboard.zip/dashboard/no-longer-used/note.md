- schema.sql for creating table
- db.py for running the sql commands in schemal.sql
- > flask -- app dashboard init-db for initializing db

- !!! no longer using these!!!