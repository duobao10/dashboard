from dashboard import app
from mqtt_receiver import mqtt_receiver
import threading

if __name__ == "__main__":
    mqtt_thread = threading.Thread(target=mqtt_receiver)
    mqtt_thread.daemon = True
    mqtt_thread.start()
    app.run(debug=True)