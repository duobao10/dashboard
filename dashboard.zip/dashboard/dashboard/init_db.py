import sqlite3

db_path = "dashboard.db"

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

with open('schema.sql') as f:
    conn.executescript(f.read())

cur = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS sensor_temperature (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sensor1 REAL,
        sensor2 REAL,
        sensor3 REAL,
        sensor4 REAL
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS evom_teer (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        barrier_resistance REAL
    )
''')

conn.commit()
conn.close()