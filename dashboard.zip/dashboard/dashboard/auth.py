from flask import Blueprint
from . import db

auth = Blueprint('auth', __name__)

@auth.route('/login')
def login():
    return 'Login'

@auth.route('/register')
def signup():
    return 'Register'

@auth.route('/logout')
def logout():
    return 'Logout'