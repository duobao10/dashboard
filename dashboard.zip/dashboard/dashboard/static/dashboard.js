
// MQTT client setup

// function delayData(){
//     temperatureData.sensor1.push(data.sensor1);
//     temperatureData.sensor2.push(data.sensor2);
//     temperatureData.sensor3.push(data.sensor3);
//     temperatureData.sensor4.push(data.sensor4);
// }
const client = mqtt.connect('ws://broker.hivemq.com:8000/mqtt'); //switchout

client.on('connect', function () {
    client.subscribe('sensor_data/temperature');
    client.subscribe('evom_data/teer');
});

client.on('message', function (topic, message) {
    console.log("Received message:", message.toString());

    try {
        const data = JSON.parse(message.toString()); // Attempt to parse the MQTT message as JSON
        let formattedTime = formatTimeLabel();
        // function timePusher(){
        //     timeLabels.push(formattedTime);
        // }
        updateLatestSensorValues(data);
        // setTimeout(timePusher, 3000);
        timeLabels.push(formattedTime);  // Add this line

        if (topic === 'sensor_data/temperature') {

            // setTimeout(delayData, 3000);
            //no effect
            temperatureData.sensor1.push(data.sensor1);
            temperatureData.sensor2.push(data.sensor2);
            temperatureData.sensor3.push(data.sensor3);
            temperatureData.sensor4.push(data.sensor4);

            updateGraphs();
            updateTable();

        } else if (topic === 'evom_data/teer') {
            // function evomPusher(){
            //     barrierResistanceData.push(data.barrierResistance);
            // }
            // setTimeout(evomPusher, 3000);
            // setTimeout(() => {
            //     barrierResistanceData.push(data.barrierResistance);
            // updateGraphs();
            // updateTable();
            // }, 10000);
            console.log("herer " + barrierResistanceData.length);
            if(barrierResistanceData.length == 64){
                temperatureData.sensor1.shift();
            }
            barrierResistanceData.push(data.barrierResistance);
            updateGraphs();
            updateTable();
        }
        if(temperatureData.sensor1.length == 64){
            temperatureData.sensor1.shift();
        }
        if(temperatureData.sensor2.length == 64){
            temperatureData.sensor2.shift();
        }
        if(temperatureData.sensor3.length == 64){
            temperatureData.sensor3.shift();
        }
        if(temperatureData.sensor4.length == 64){
            temperatureData.sensor4.shift();
        }
        updateGraphs();
        updateTable();
    } catch (e) {
        console.error("Error parsing JSON:", e);
    }
});

// function getRandomNumber(min, max) {
//     return Math.random() * (max - min) + min;
// }

// Create an array to store the random data points

// Generate 400 random data points
// for (let i = 0; i < 400; i++) {
//     // Generate a random number between 0 and 100 (for example)
//     let randomNumber = getRandomNumber(0, 100);
    
//     // Add the random number to the array
//     randomDataPoints.push(randomNumber);
// }


const maxBarrierResistance = 15000; // max 15000 Ohms*cm²
const maxTemperature = 50; // max 50°C
let timeLabels = [];
let barrierResistanceData = [50, 10000, 200, 5000, 1000];
// for (let i = 0; i < 400; i++) {
//     // Generate a random number between 0 and 100 (for example)
//     let randomNumber = getRandomNumber(0, 10000);
    
//     // Add the random number to the array
//     barrierResistanceData.push(randomNumber);
// }
let temperatureData = {
    sensor1: [50, 10000, 200, 5000, 300],
    sensor2: [50, 10000, 200, 5000, 6],
    sensor3: [50, 10000, 200, 5000, 200],
    sensor4: [50, 10000, 200, 5000, 50]
};
let graph1, graph2, graph3;
let elapsedSeconds = 0;
let updateInterval = 1000; // 10 seconds

// Function to format time labels for the graph
function formatTimeLabel() {
    if (elapsedSeconds < 60) {
        return elapsedSeconds + 's';
    } else if (elapsedSeconds < 3600) {
        return Math.floor(elapsedSeconds / 60) + 'm';
    } else {
        return Math.floor(elapsedSeconds / 3600) + 'h';
    }
}

function updateLatestSensorValues(data) {
    const sensorValuesElement = document.getElementById('sensorValues');
    sensorValuesElement.innerHTML = `Barrier Resistance: ${data.barrierResistance}, Sensor 1: ${data.sensor1}, Sensor 2: ${data.sensor2}, Sensor 3: ${data.sensor3}, Sensor 4: ${data.sensor4}`;
    // console.log(sensorValuesElement.innerHTML);
}

function timeToSeconds(timeString) {
    // Check if the time string ends with 'm' (minutes)
    if (timeString.endsWith('m')) {
        // Extract the numerical part of the string (excluding the 'm')
        var minutes = parseInt(timeString.slice(0, -1), 10);
        // Convert minutes to seconds (1 minute = 60 seconds)
        return minutes * 60;
    }
    // else if(timeString.endsWith('h')){
    //     let hours = parseInt(timeString.slice(0, -1), 10);
    //     return hours * 3600;
    // } 
    else {
        // If the time string is not in the expected format, return NaN
        return NaN;
    }
}

// Function to update data and adjust interval
function updateData() {
    let formattedTime = formatTimeLabel();
    //works for initial time
    // function timePusher2(){
    //     timeLabels.push(formattedTime);
    // }
    //   setTimeout(timePusher2, 20000);
    // if(timeLabels.length <= 300){
    //     timeLabels.push(formattedTime);
    // }
    if(formattedTime.includes('m')){
        let convertTime = timeToSeconds(formattedTime);
        // console.log(convertTime);
        if(convertTime<=300){
            timeLabels.push(formattedTime);
            // console.log("herer" + formattedTime); 
            // updateGraphs();
            // updateTable();
        }
    }
    // else if(formattedTime.includes('h')){
    //     let convertTime = timeToSeconds(formattedTime);
    //     // console.log(convertTime);
    //     if(convertTime<=300){
    //         timeLabels.push(formattedTime);
    //         // console.log("herer" + formattedTime); 
    //         // updateGraphs();
    //         // updateTable();
    //     }
    // }
    else if(formattedTime.includes('s')){
        timeLabels.push(formattedTime);
        // console.log(formattedTime);
    }
    // let convertTime = timeToSeconds(formattedTime);
    // timeLabels.push(formattedTime);
    // console.log(formattedTime);
    updateGraphs();
    updateTable();

    // Update the interval
    elapsedSeconds += updateInterval / 1000;
    if (elapsedSeconds >= 60 && elapsedSeconds < 3600) {
        updateInterval = 60000; // Update every 1 minute
    } else if (elapsedSeconds >= 3600) {
        updateInterval = 3600000; // Update every 1 hour
    }

    setTimeout(updateData, updateInterval);
}

// Function to update graphs with new data
function updateGraphs() {
    // setTimeout(() => {
    //     addDataToGraph(graph1, timeLabels, barrierResistanceData, 'Barrier Resistance (Ohms*cm²)', 'blue');
    // }, 10000);
    const sensorValuesElement = document.getElementById('sensorValues');
    sensorValuesElement.innerHTML = `Barrier Resistance: ${barrierResistanceData[barrierResistanceData.length-1]}, Sensor 1: ${temperatureData.sensor1[temperatureData.sensor1.length-1]},
     Sensor 2: ${temperatureData.sensor2[temperatureData.sensor2.length-1]}, Sensor 3: ${temperatureData.sensor3[temperatureData.sensor3.length-1]}, Sensor 4: ${temperatureData.sensor4[temperatureData.sensor4.length-1]}`;
    // console.log(sensorValuesElement.innerHTML);
    addDataToGraph(graph1, timeLabels, barrierResistanceData, 'Barrier Resistance (Ohms*cm²)', 'blue');
    addDataToGraph2(graph2, temperatureData.sensor1, 'Sensor 1 (°C)', 'red');
    // setTimeout(() => {
    //     addDataToGraph2(graph2, temperatureData.sensor1, 'Sensor 1 (°C)', 'red');
    // }, 10000);
    // setTimeout(()=>{
    //     addDataToGraph2(graph3, barrierResistanceData, 'Combined Barrier Resistance (Ohms*cm²)', 'blue', temperatureData.sensor1, 'Sensor 1 (°C)', 'red');
    // }, 10000)
    addDataToGraph2(graph3, barrierResistanceData, 'Combined Barrier Resistance (Ohms*cm²)', 'blue', temperatureData.sensor1, 'Sensor 1 (°C)', 'red');
}

// Function to add data to a graph
function addDataToGraph(graph, labels, data, label, borderColor, data2 = null, label2 = '', borderColor2 = '') {
    // setTimeout(() => {
        
    // }, 10000);
    graph.data.labels = labels;
    graph.data.datasets[0].data = data;
    graph.data.datasets[0].label = label;
    graph.data.datasets[0].borderColor = borderColor;

    if (data2 !== null) {
        graph.data.datasets[1].data = data2;
        graph.data.datasets[1].label = label2;
        graph.data.datasets[1].borderColor = borderColor2;
    }

    // setTimeout(() => {
    //     graph.update()
    // }, 10000);
    graph.update();
}

function addDataToGraph2(graph, data, label, borderColor, data2 = null, label2 = '', borderColor2 = '') {
    graph.data.labels = generateTimeLabels(graph);
    graph.data.datasets[0].data = data;
    graph.data.datasets[0].label = label;
    graph.data.datasets[0].borderColor = borderColor;

    if (data2 !== null) {
        graph.data.datasets[1].data = data2;
        graph.data.datasets[1].label = label2;
        graph.data.datasets[1].borderColor = borderColor2;
    }

    graph.update();
}
function formatTimeLabel1(totalSeconds) {
    let hours = Math.floor(totalSeconds / 3600);
    let minutes = Math.floor((totalSeconds - (hours * 3600)) / 60);
    let seconds = totalSeconds - (hours * 3600) - (minutes * 60);

    // Padding with '0' if necessary
    hours = hours < 10 ? '0' + hours : hours;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    seconds = seconds < 10 ? '0' + seconds : seconds;

    return hours + ':' + minutes + ':' + seconds;
}

function generateTimeLabels(chart) {
    let labels = [];

   let totalDuration = chart.data.datasets[1].data.length; // Assuming each data point is one second explain this

    for (let i = 0; i < totalDuration; i++) {
        // function timePusher3(){
        //     labels.push(formatTimeLabel1(i));
        // }
        // setTimeout(timePusher3, 20000);
        labels.push(formatTimeLabel1(i));
    }

    return labels;
}

// setTimeout(2    )
// Function to update the table with the latest 10 data points
function updateTable() {
    const dataTableBody = document.getElementById('dataTableBody');
    dataTableBody.innerHTML = ''; // Clear existing data

    // Determine the number of rows to display based on the data available
    let numRows = Math.max(barrierResistanceData.length, temperatureData.sensor1.length);
    let startIndex = Math.max(0, numRows - 10);

    for (let i = startIndex; i < numRows; i++) {
        const row = dataTableBody.insertRow(-1);

        // Barrier Resistance Data
        let barrierValue = barrierResistanceData[i] ? barrierResistanceData[i].toFixed(2) : 'N/A';
        row.insertCell(0).textContent = barrierValue;

        // Temperature Data
        let temp1 = temperatureData.sensor1[i] ? temperatureData.sensor1[i].toFixed(2) : 'N/A';
        let temp2 = temperatureData.sensor2[i] ? temperatureData.sensor2[i].toFixed(2) : 'N/A';
        let temp3 = temperatureData.sensor3[i] ? temperatureData.sensor3[i].toFixed(2) : 'N/A';
        let temp4 = temperatureData.sensor4[i] ? temperatureData.sensor4[i].toFixed(2) : 'N/A';

        row.insertCell(1).textContent = temp1;
        row.insertCell(2).textContent = temp2;
        row.insertCell(3).textContent = temp3;
        row.insertCell(4).textContent = temp4;
    }
}

// Initialize the graphs
function initializeGraphs() {
    const ctx1 = document.getElementById('graph1').getContext('2d');
    graph1 = new Chart(ctx1, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{ label: 'Barrier Resistance (Ohms*cm²)', data: barrierResistanceData, borderColor: 'blue', borderWidth: 1 }]
        },
        options: { scales: { y: { beginAtZero: true, max: maxBarrierResistance } } }
    });

    const ctx2 = document.getElementById('graph2').getContext('2d');
    graph2 = new Chart(ctx2, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [
                { label: 'Sensor 1 (°C)', data: temperatureData.sensor1, borderColor: 'red', borderWidth: 1 },
                { label: 'Sensor 2 (°C)', data: temperatureData.sensor2, borderColor: 'green', borderWidth: 1 },
                { label: 'Sensor 3 (°C)', data: temperatureData.sensor3, borderColor: 'orange', borderWidth: 1 },
                { label: 'Sensor 4 (°C)', data: temperatureData.sensor4, borderColor: 'purple', borderWidth: 1 }
            ]
        },
        options: { scales: { y: { beginAtZero: false }, x: { ticks: { maxTicksLimit: 20 } } },
        plugins: {
            zoom: {
                zoom: {
                    onZoom: function ({ chart }) {
                        chart.data.labels = generateTimeLabels(chart);
                        chart.update();
                    },
                    wheel: { enabled: true },
                    pinch: { enabled: true },
                    mode: 'x'
                },
                pan: {
                    onPan: function ({ chart }) {
                        chart.data.labels = generateTimeLabels(chart);
                        chart.update();
                    },
                    enabled: true,
                    mode: 'x'
                }
            }
        } }
    });

    const ctx3 = document.getElementById('graph3').getContext('2d');
    graph3 = new Chart(ctx3, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [
                { label: 'Barrier Resistance (Ohms*cm²)', data: barrierResistanceData, borderColor: 'blue', borderWidth: 1, yAxisID: 'y1' },
                { label: 'Sensor 1 (°C)', data: temperatureData.sensor1, borderColor: 'red', borderWidth: 1, yAxisID: 'y2' },
                { label: 'Sensor 2 (°C)', data: temperatureData.sensor2, borderColor: 'green', borderWidth: 1, yAxisID: 'y2' },
                { label: 'Sensor 3 (°C)', data: temperatureData.sensor3, borderColor: 'orange', borderWidth: 1, yAxisID: 'y2' },
                { label: 'Sensor 4 (°C)', data: temperatureData.sensor4, borderColor: 'purple', borderWidth: 1, yAxisID: 'y2' }
            ]
        },
        options: {
            scales: {
                y1: { type: 'linear', display: true, position: 'left',min: 0 , max: maxBarrierResistance  },
                y2: { type: 'linear', display: true, position: 'right' },
                x: {
                    ticks: {
                        maxTicksLimit: 20
                    }
                }
            },
            plugins: {
                zoom: {
                    zoom: {
                        onZoom: function ({ chart }) {
                            chart.data.labels = generateTimeLabels(chart);
                            chart.update();
                        },
                        wheel: { enabled: true },
                        pinch: { enabled: true },
                        mode: 'x'
                    },
                    pan: {
                        onPan: function ({ chart }) {
                            chart.data.labels = generateTimeLabels(chart);
                            chart.update();
                        },
                        enabled: true,
                        mode: 'x'
                    }
                }
            } 
        }
    });
}
// Start the application
initializeGraphs();
updateData();
