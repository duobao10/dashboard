import os
from flask import Flask
import paho.mqtt.client as mqtt
import sqlite3
import json

from dashboard.routes import bp


# def create_app(test_config=None):
# create and configure the app
app = Flask(__name__, instance_relative_config=True)

app.config.from_mapping(
    SECRET_KEY='dev',
    # DATABASE=os.path.join(app.instance_path, 'dashboard.sqlite'),
    # DATABASE=os.path.join(app.instance_path, 'your_database.db'),
    
    # db file is in the parent directory
    DATABASE=os.path.join(os.path.dirname(app.instance_path), 'your_database.db'),
)

# if test_config is None:
#     # load the instance config, if it exists, when not testing
#     app.config.from_pyfile('config.py', silent=True)
# else:
#     # load the test config if passed in
#     app.config.from_mapping(test_config)

# ensure the instance folder exists
try:
    os.makedirs(app.instance_path)
except OSError:
    pass



# from . import db
# db.init_app(app)

# from . import auth
# app.register_blueprint(auth.bp)

# connect_and_listen()




# return app




# create user table
# def create_user_table(cursor: sqlite3.Cursor):
#     command = """CREATE TABLE user (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 username TEXT UNIQUE NOT NULL,
#                 password TEXT NOT NULL);"""
#     cursor.execute(command)


app.register_blueprint(bp)


# create user table
db_path = "./your_database.db"
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

command = """CREATE TABLE IF NOT EXISTS user (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL);"""
            
cursor.execute(command)