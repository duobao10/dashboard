DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS sensor_temperature;
DROP TABLE IF EXISTS evom_teer;

CREATE TABLE user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL
);

CREATE TABLE sensor_temperature (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sensor1 REAL,
    sensor2 REAL,
    sensor3 REAL,
    snsoer4 REAL
);

CREATE TABLE evom_teer (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    barrier_resistance REAL
);